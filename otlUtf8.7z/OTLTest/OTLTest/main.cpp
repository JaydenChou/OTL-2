//ʹ��UTF8�ַ���, 2��ע���

#include <iostream>
using namespace std;	
#pragma comment(lib, "oci.lib")
#define	OTL_ORA11G_R2
#define OTL_ORA_UTF8		//ʹ��UTF8�ַ���, ע���1
#include "otlv4.h"
#include "CodingConv.h"

otl_connect db;

void insert()
{ 
	otl_stream o
		(50,
		"insert into test_tab values(:f1<int>,:f2<nchar[31]>)",
		db
		);

	char tmp[256];
	char chValue[256];
	for (int i=1; i<=20; ++i)
	{
		sprintf(tmp, "����%d", i);
		CCodingConv::Instance()->GbkToUtf8(chValue, 128, tmp);
		o << i << chValue;
	}
}

void select()
{ 
	otl_stream i(50, // buffer size
		"select * from test_tab where f1>=:f<int> and f1<=:f*2",
		db // connect object
		); 

	float f1;
	char f2[31];
	i << 4;

	while(!i.eof())
	{
		i >> f1 >> f2;
		char chValue[128];
		CCodingConv::Instance()->Utf8ToGbk(chValue, 128, f2);
		cout << "f1=" << f1 << ", f2=" << chValue << endl;
	}

}

int main()
{
	//putenv(const_cast<char*>("NLS_LANG=.AL32UTF8"));
	putenv("NLS_LANG=.AL32UTF8"); 		//ʹ��UTF8�ַ���, ע���2

	otl_connect::otl_initialize();
	try
	{
		db.rlogon("ffap/qdxjxxc@192.168.3.131:1521/orcl");
		db.direct_exec("drop table test_tab", otl_exception::disabled);
		otl_cursor::direct_exec(db, "create table test_tab(f1 number, f2 varchar2(30))");  // create table

		insert();
		select();
		db.logoff();
	}
	catch(otl_exception& e)
	{
		cerr << "ERROR: code[" <<e.code<<"] ";
		cerr << e.msg << endl;
		cerr << e.stm_text << endl;
		cerr << e.var_info << endl;
	}
	
	//db.logoff();
	return 0;
}
