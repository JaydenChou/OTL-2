// CodingConv.cpp: implementation of the CCodingConv class.

#include "CodingConv.h"
#include <windows.h>

CCodingConv* CCodingConv::_instance = NULL;

CCodingConv::CCodingConv()
{

}

CCodingConv* CCodingConv::Instance()
{
	if (_instance == nullptr)
	{
		_instance = new CCodingConv;
	}

	return _instance;
}

void CCodingConv::Gb2312_2_Unicode(unsigned short* dst, const char * src)
{
	::MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, src, 2, dst, 1);
}

void CCodingConv::Unicode_2_UTF8(char* dst, unsigned short* src)
{
	 char* pchar = (char *)src;
 
	 dst[0] = (0xE0 | ((pchar[1] & 0xF0) >> 4));
	 dst[1] = (0x80 | ((pchar[1] & 0x0F) << 2)) + ((pchar[0] & 0xC0) >> 6);
	 dst[2] = (0x80 | ( pchar[0] & 0x3F));
}

void CCodingConv::UTF8_2_Unicode(unsigned short* dst, const char * src)
{
	 char* uchar = (char *)dst;
 
	 uchar[1] = ((src[0] & 0x0F) << 4) + ((src[1] >> 2) & 0x0F);
	 uchar[0] = ((src[1] & 0x03) << 6) + (src[2] & 0x3F);
}

void CCodingConv::Unicode_2_GB2312(char* dst, unsigned short uData)
{
	WideCharToMultiByte(CP_ACP, NULL, &uData, 1, dst, sizeof(unsigned short), NULL, NULL);
}

int CCodingConv::GbkToUtf8(char * buf, int buf_len, const char * src, int src_len)
{
	if (0 == src_len)
	{
		src_len = strlen(src);
	}
	
	int j = 0;
	for (int i = 0; i < src_len;)
	{
		if (j >= buf_len - 1)
		{
			break;
		}
		if (src[i] >= 0)
		{
			buf[j++] = src[i++];
		}
		else
		{
			unsigned short w_c = 0;
			Gb2312_2_Unicode(&w_c, src + i);
			char tmp[4] = "";
			Unicode_2_UTF8(tmp, &w_c);
   
			buf[j+0] = tmp[0];
			buf[j+1] = tmp[1];
			buf[j+2] = tmp[2];
   
			i += 2;
			j += 3;
		}
	}
	buf[j] = '\0';
	return j;
}

int CCodingConv::Utf8ToGbk(char * buf, int buf_len, const char * src, int src_len)
{
	if (0 == src_len)
	{
		src_len = strlen(src);
	}

	int j = 0;
	for (int i = 0; i < src_len;)
	{
		if (j >= buf_len - 1)
		{
			break;
		}
		if (src[i] >= 0)
		{
			buf[j++] = src[i++];
		}
		else
		{
			unsigned short w_c = 0;
			UTF8_2_Unicode(&w_c, src + i);

			char tmp[4] = "";
			Unicode_2_GB2312(tmp, w_c);

			buf[j+0] = tmp[0];
			buf[j+1] = tmp[1];

			i += 3;
			j += 2;
		}
	}

	buf[j] = '\0';

	return j;
}

wchar_t* CCodingConv::GbkToUnicode(const char* c)
{  
	wchar_t *m_wchar;
	//��ȡ����Ŀ��ַ���
	int len = MultiByteToWideChar(CP_ACP, 0, c, strlen(c), NULL, 0);  
	m_wchar = new wchar_t[len+1];  
	MultiByteToWideChar(CP_ACP, 0, c, strlen(c), m_wchar,len);  
	m_wchar[len] = '\0';
	return m_wchar;  
}

char* CCodingConv::UnicodeToGbk(const wchar_t* wp)
{    
	char *m_char;  
	//��ȡ������ַ���
	int len = WideCharToMultiByte(CP_ACP, 0, wp, wcslen(wp), NULL, 0, NULL, NULL);    
	m_char = new char[len+1];    
	WideCharToMultiByte(CP_ACP, 0, wp, wcslen(wp), m_char, len, NULL, NULL);    
	m_char[len] = '\0';    
	return m_char;    
}  